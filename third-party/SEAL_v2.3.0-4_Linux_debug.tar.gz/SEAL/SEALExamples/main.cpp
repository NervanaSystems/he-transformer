#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <chrono>
#include <random>
#include <thread>
#include <mutex>
#include <random>
#include <limits>

#include "seal/seal.h"

using namespace std;
using namespace seal;

/*
Helper function: Prints the name of the example in a fancy banner.
*/
void print_example_banner(string title)
{
    if (!title.empty())
    {
        size_t title_length = title.length();
        size_t banner_length = title_length + 2 + 2 * 10;
        string banner_top(banner_length, '*');
        string banner_middle = string(10, '*') + " " + title + " " + string(10, '*');

        cout << endl
            << banner_top << endl
            << banner_middle << endl
            << banner_top << endl
            << endl;
    }
}

/*
Helper function: Prints the parameters in a SEALContext.
*/
void print_parameters(const SEALContext &context)
{
    cout << "/ Encryption parameters:" << endl;
    cout << "| poly_modulus: " << context.poly_modulus().to_string() << endl;

    /*
    Print the size of the true (product) coefficient modulus
    */
    cout << "| coeff_modulus size: "
        << context.total_coeff_modulus().significant_bit_count() << " bits" << endl;

    cout << "| plain_modulus: " << context.plain_modulus().value() << endl;
    cout << "\\ noise_standard_deviation: " << context.noise_standard_deviation() << endl;
    cout << endl;
}

void example_basics_i();


int main()
{
    example_basics_i();
    return 0;
}

void example_basics_i()
{
    print_example_banner("Example: Basics I");
    EncryptionParameters parms;

    size_t mod = 8192;
    parms.set_poly_modulus("1x^" + to_string(mod) + " + 1");

    parms.set_coeff_modulus(coeff_modulus_128(8192));
    parms.set_plain_modulus(1 << 5);

    SEALContext context(parms);

    print_parameters(context);
    IntegerEncoder encoder(context.plain_modulus());

    KeyGenerator keygen(context);
    PublicKey public_key = keygen.public_key();
    SecretKey secret_key = keygen.secret_key();

    Encryptor encryptor(context, public_key);

    Evaluator evaluator(context);

    Decryptor decryptor(context, secret_key);

    int base = 2;
    double value2 = 7.5;
    cout << endl << endl << "base " << base << endl;
    FractionalEncoder fencoder(context.plain_modulus(), context.poly_modulus(), 64, 32, base);
    Plaintext plain2 = fencoder.encode(value2);
    cout << "Encoded " << value2 << " as polynomial " << plain2.to_string() << " (base " << base << ")"<< endl;

    double value1 = 1.2;
    Plaintext plain1 = fencoder.encode(value1);
    cout << "Encoded " << value1 << " as polynomial " << plain1.to_string() << " (plain1)" << endl;

    /*
    Encrypting the values is easy.
    */
    Ciphertext encrypted1, encrypted2;
    encryptor.encrypt(plain1, encrypted1);

    encryptor.encrypt(plain2, encrypted2);

    cout << "Noise budget in encrypted1: "
        << decryptor.invariant_noise_budget(encrypted1) << " bits" << endl;
    cout << "Noise budget in encrypted2: "
        << decryptor.invariant_noise_budget(encrypted2) << " bits" << endl;

    evaluator.negate(encrypted1);
    cout << "Noise budget in -encrypted1: "
        << decryptor.invariant_noise_budget(encrypted1) << " bits" << endl;

    evaluator.add(encrypted1, encrypted2);
    cout << "Noise budget in -encrypted1 + encrypted2: "
        << decryptor.invariant_noise_budget(encrypted1) << " bits" << endl;

    for (int i = 0; i < 8; ++i)
    {
        evaluator.multiply(encrypted1, encrypted2);
        for(int j = 0; j < 100; ++j)
        {
            evaluator.add(encrypted1, encrypted2);
        }
        int budget = decryptor.invariant_noise_budget(encrypted1);
        if (budget <= 0)
        {
            cout << "Noise budget exhausted at mult " << i << endl;
            throw ("Noise budget exhausted");
        }
        cout << "Mult " << i << " budget " << budget << endl;
    }

    cout << "Noise budget in (-encrypted1 + encrypted2) * encrypted2: "
        << decryptor.invariant_noise_budget(encrypted1) << " bits" << endl;

    Plaintext plain_result;
    cout << "Decrypting result: ";
    decryptor.decrypt(encrypted1, plain_result);
    cout << "Done" << endl;

    cout << "Plaintext polynomial: " << plain_result.to_string() << endl;

    // cout << "Decoded integer: " << encoder.decode_int32(plain_result) << endl;
    cout << "Decoded float: " << fencoder.decode(plain_result) << endl;
}
