/* config.h.  Generated from config.h.in by configure.  */
#define SEAL_ENABLE_INTRIN 1
#define SEAL_ENABLE___BUILTIN_CLZLL 1
#define SEAL_ENABLE___INT128 1
#define SEAL_ENABLE__ADDCARRY_U64 1
#define SEAL_ENABLE__SUBBORROW_U64 1
